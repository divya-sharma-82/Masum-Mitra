# Mausam Mitra — Delivery Outcomes

- **Live weather dashboard:** Show live current temperature, feels-like temperature, humidity, wind speed, UV index, AQI, visibility, sunrise/sunset, and rain probability from a real weather data API.
- **Forecast and location:** Provide hourly and 7-day forecasts, city search, selected location, and device geolocation.
- **Smart warnings:** Surface severity-aware warnings for heavy rain, heatwave, storm/high wind, poor visibility, and high UV.
- **Recommendations:** Provide umbrella, outdoor timing, heat safety, farming/irrigation, and travel guidance.
- **Audience modes:** Include resident/daily planner, farmer, traveler, and regional overview contexts.
- **Bilingual interface:** English and Hindi switching for core navigation, weather labels, warnings, recommendations, and actions.
- **Responsive and accessible states:** Mobile-first responsive layout, accessible controls, loading, permission-denied, and error states.
