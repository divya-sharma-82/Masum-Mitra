export default {
  logoUrl: "https://openmoji.org/data/color/svg/2600.svg",
};
