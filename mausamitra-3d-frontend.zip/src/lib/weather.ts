export type Place = { name: string; country: string; latitude: number; longitude: number; admin1?: string };
export type WeatherData = {
  place: Place; updatedAt: Date; temp: number; feels: number; humidity: number; wind: number; windDir: number;
  precipitation: number; rainChance: number; uv: number; visibility: number; aqi: number; weatherCode: number;
  sunrise: string; sunset: string; hourly: { time: string; temp: number; rain: number; code: number }[];
  daily: { date: string; max: number; min: number; rain: number; code: number; uv: number }[];
};

const forecastUrl = (p: Place) => `https://api.open-meteo.com/v1/forecast?latitude=${p.latitude}&longitude=${p.longitude}&timezone=auto&forecast_days=7&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,wind_speed_10m,wind_direction_10m&hourly=temperature_2m,precipitation_probability,weather_code,visibility&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max,sunrise,sunset`;
const airUrl = (p: Place) => `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${p.latitude}&longitude=${p.longitude}&timezone=auto&hourly=us_aqi`;

export const searchPlaces = async (query: string): Promise<Place[]> => {
  const r = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=6&language=en&format=json`);
  if (!r.ok) throw new Error('Search failed');
  const j = await r.json();
  return (j.results ?? []).map((x: any) => ({ name: x.name, country: x.country ?? '', latitude: x.latitude, longitude: x.longitude, admin1: x.admin1 }));
};

export const fetchWeather = async (place: Place): Promise<WeatherData> => {
  const [wr, ar] = await Promise.all([fetch(forecastUrl(place)), fetch(airUrl(place))]);
  if (!wr.ok) throw new Error('Weather service unavailable');
  const w = await wr.json(); const a = ar.ok ? await ar.json() : { hourly: { us_aqi: [0] } };
  const now = new Date();
  const currentIndex = Math.max(0, w.hourly.time.findIndex((t: string) => new Date(t) >= now));
  return {
    place, updatedAt: now, temp: Math.round(w.current.temperature_2m), feels: Math.round(w.current.apparent_temperature),
    humidity: w.current.relative_humidity_2m, wind: Math.round(w.current.wind_speed_10m), windDir: w.current.wind_direction_10m,
    precipitation: w.current.precipitation, rainChance: w.hourly.precipitation_probability[currentIndex] ?? 0,
    uv: Math.round(w.daily.uv_index_max[0]), visibility: Math.round((w.hourly.visibility[currentIndex] ?? 10000) / 1000),
    aqi: Math.round(a.hourly.us_aqi[currentIndex] ?? a.hourly.us_aqi[0] ?? 0), weatherCode: w.current.weather_code,
    sunrise: w.daily.sunrise[0], sunset: w.daily.sunset[0],
    hourly: w.hourly.time.slice(currentIndex, currentIndex + 8).map((time: string, i: number) => ({ time, temp: Math.round(w.hourly.temperature_2m[currentIndex + i]), rain: w.hourly.precipitation_probability[currentIndex + i] ?? 0, code: w.hourly.weather_code[currentIndex + i] })),
    daily: w.daily.time.map((date: string, i: number) => ({ date, max: Math.round(w.daily.temperature_2m_max[i]), min: Math.round(w.daily.temperature_2m_min[i]), rain: w.daily.precipitation_probability_max[i] ?? 0, code: w.daily.weather_code[i], uv: Math.round(w.daily.uv_index_max[i]) })),
  };
};

export const getCurrentPlace = (): Promise<Place> => new Promise((resolve, reject) => {
  if (!navigator.geolocation) return reject(new Error('Geolocation unavailable'));
  navigator.geolocation.getCurrentPosition(async ({ coords }) => {
    try { const places = await searchPlaces(`${coords.latitude},${coords.longitude}`); resolve(places[0] ?? { name: 'Your location', country: '', latitude: coords.latitude, longitude: coords.longitude }); }
    catch { resolve({ name: 'Your location', country: '', latitude: coords.latitude, longitude: coords.longitude }); }
  }, () => reject(new Error('Location permission denied')), { timeout: 7000 });
});

export const codeIcon = (code: number) => code === 0 ? '☀️' : code < 4 ? '🌤️' : code < 60 ? '☁️' : code < 80 ? '🌧️' : code < 95 ? '🌨️' : '⛈️';
export const codeText = (code: number) => code === 0 ? 'Clear sky' : code < 4 ? 'Partly cloudy' : code < 60 ? 'Cloudy' : code < 80 ? 'Rain showers' : code < 95 ? 'Snow showers' : 'Thunderstorm';
export const windDirection = (d: number) => ['N','NE','E','SE','S','SW','W','NW'][Math.round(d / 45) % 8];
