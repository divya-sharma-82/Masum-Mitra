import { Canvas, useFrame } from '@react-three/fiber';
import { Environment, Float, OrbitControls, Sparkles, useGLTF } from '@react-three/drei';
import { Suspense, useRef } from 'react';
import * as THREE from 'three';

type Props = { rain?: boolean; storm?: boolean };

function MascotModel({ rain = false, storm = false }: Props) {
  const { scene } = useGLTF('/mausam-mascot.glb');
  const group = useRef<THREE.Group>(null);
  useFrame((state, delta) => {
    if (!group.current) return;
    group.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.55) * 0.16;
    group.current.position.y = Math.sin(state.clock.elapsedTime * 1.2) * 0.04;
    group.current.rotation.z = THREE.MathUtils.lerp(group.current.rotation.z, rain ? -0.03 : 0, delta * 3);
  });
  return <group ref={group} scale={1.75} position={[0, -0.82, 0]}><primitive object={scene} /><Sparkles count={storm ? 18 : rain ? 40 : 8} scale={[2.5, 2.5, 2.5]} size={rain ? 3 : 2} speed={rain ? 2.5 : .35} color={storm ? '#c19be7' : rain ? '#8ccfe3' : '#f7c64b'} /></group>;
}

export default function WeatherMascot({ rain = false, storm = false }: Props) {
  return <div className="weather-3d" aria-label="Animated 3D weather mascot" role="img"><Canvas camera={{ position: [0, 0.25, 4.8], fov: 38 }} dpr={[1, 1.6]} gl={{ antialias: true, alpha: true }}><ambientLight intensity={1.4} /><directionalLight position={[3, 5, 4]} intensity={2.5} color={storm ? '#c8b9ff' : '#fff5ce'} /><pointLight position={[-3, 1, 2]} intensity={1.2} color="#9bd6cb" /><Suspense fallback={null}><Environment preset="city" /><Float speed={1.2} rotationIntensity={0.12} floatIntensity={0.35}><MascotModel rain={rain} storm={storm} /></Float></Suspense><OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.28} /></Canvas><span className="model-caption">Live sky buddy</span></div>;
}

useGLTF.preload('/mausam-mascot.glb');
