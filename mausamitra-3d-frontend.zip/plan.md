# Mausam Mitra — Implementation & Design Plan

## Product scope

Mausam Mitra is an all-in-one, live weather companion for residents/daily planners, farmers, and travelers. It uses live weather and air-quality data, supports city search and device location, and turns forecast signals into practical, severity-aware guidance. The first release is a static client application that calls browser-safe public weather endpoints directly; no login or server-side persistence is required for the requested experience.

## Implementation approach

- Use a lightweight Vite + React + TypeScript frontend served on port 3000.
- Use Open-Meteo geocoding, forecast, and air-quality endpoints for live data without exposing a secret key. Current conditions, hourly forecast, daily forecast, UV, precipitation probability, wind, humidity, visibility, sunrise/sunset, and AQI are requested from the APIs.
- Use browser geolocation when available, with New Delhi as a safe initial fallback and a visible location/search control.
- Normalize API responses into typed view models in `src/lib/weather.ts`; keep loading, empty, permission-denied, and API-error states explicit.
- Derive smart alerts and recommendations locally from live readings: heat, rain, wind/storm, visibility, UV, and travel/farming/outdoor advice.
- Keep English/Hindi strings in `src/lib/i18n.ts` and toggle the complete visible app copy, not only the title.
- Use deterministic CSS and inline SVG icons so the interface is visually rich without additional asset dependencies.
- Add `public/manus-routes.json` for the root route and keep document metadata/fallback accessible.

## Design direction

### Design movement
Weather editorial meets friendly civic-tech: calm, optimistic, data-literate, and approachable rather than clinical. The reference's clean civic storytelling is retained, but the visual language shifts from waste/greenery to sky, forecast bands, and ambient climate cues.

### Core principles
1. **Scan in seconds:** location, current condition, temperature, and next action are visible above the fold.
2. **Signal over noise:** a limited hierarchy of cards turns many weather metrics into a few useful decisions.
3. **Human guidance:** every risk signal pairs with plain-language advice for real life.
4. **Calm preparedness:** alerts are prominent but never alarmist; color is reserved for severity.

### Color philosophy
A deep evergreen ink anchors trust and legibility. Mist blue and pale sky create calm, while a warm sun-yellow marks optimism and action. Mint and lilac provide subtle mode differentiation. Amber/red are reserved for weather risk, so important warnings remain unmistakable.

### Layout paradigm
A **forecast ribbon** layout: a wide editorial hero establishes place and temperature, followed by a horizontal signal rail, a primary forecast column, and a side guidance column. Cards are modular but intentionally varied in width to avoid a generic dashboard grid.

### Signature elements
- A compact `MM` sun/cloud wordmark and friendly sky mascot made from inline SVG.
- A temperature dial/ring with a small animated sun pulse.
- Forecast ribbons with time labels, weather icons, and precipitation markers.

### Interaction and animation
Search and location actions update the entire dashboard with a brief crossfade; cards lift 2px on hover; the hero sun uses a very subtle pulse; forecast bars animate once when data arrives. Respect reduced-motion preferences. Buttons have visible keyboard focus and status text remains readable without animation.

### Typography system
Use `Inter` for readable data and controls with a high-contrast editorial serif fallback (`Georgia`) for the word “Mausam” and select hero emphasis. Headlines are bold and compact; metric values use tabular numerals; body copy stays at a comfortable 15–16px line height.

### Brand essence
**Mausam Mitra — live weather intelligence that helps every kind of day go better.** Personality: helpful, grounded, ready.

### Brand voice
Headlines are short and reassuring. CTAs are direct and practical.
- “Plan your day with the sky on your side.”
- “Rain is likely. Here’s the better time to step out.”

### Wordmark and signature brand color
The wordmark combines a rounded `MM` cloud/sun mark with “Mausam” in evergreen sans and “Mitra” in an italic serif accent. Signature brand color: **Mitra Evergreen `#125C4A`**, a recognizable blend of civic trust and natural calm.

## Project structure

- `index.html` — app shell, metadata, font loading.
- `src/main.tsx` — React entrypoint.
- `src/App.tsx` — page composition, state, interactions, responsive dashboard.
- `src/styles.css` — design system, responsive layout, motion, accessibility.
- `src/lib/weather.ts` — typed Open-Meteo fetching, normalization, geolocation/search helpers, alert/recommendation derivation.
- `src/lib/i18n.ts` — English/Hindi product copy.
- `public/manus-routes.json` — declared page routes.
- `app.config.ts` — project logo metadata.

## Material constraints

- No API key is required for the initial Open-Meteo client integration.
- The app must remain usable when location permission is denied or the API is unavailable.
- Live timestamps and “updated” labels must be based on the actual fetch, not hard-coded demo claims.
- The browser-facing app must listen on `0.0.0.0:3000` for Preview compatibility.
